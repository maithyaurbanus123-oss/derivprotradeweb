require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.CORS_ORIGIN || '*', methods: ['GET','POST'] }
});

let chatHistory = [];
const users = new Map();

io.on('connection', (socket) => {
  socket.on('join', ({username}) => {
    users.set(socket.id, { username: username || 'Anon', joinedAt: Date.now() });
    socket.emit('history', chatHistory);
    socket.broadcast.emit('user_joined', { socketId: socket.id, username });
    io.emit('users', Array.from(users.values()));
  });
  socket.on('message', (msg) => {
    const user = users.get(socket.id) || { username: 'Anon' };
    const entry = { user: user.username, text: msg.text, ts: Date.now() };
    chatHistory.push(entry); if(chatHistory.length > 500) chatHistory.shift();
    io.emit('message', entry);
  });
  socket.on('disconnect', () => {
    const user = users.get(socket.id);
    users.delete(socket.id);
    if(user) socket.broadcast.emit('user_left', { username: user.username });
  });
});

app.use('/public', express.static(path.join(__dirname, 'public')));
app.get('/health', (req,res)=>res.json({ok:true}));

server.listen(process.env.PORT || 3000, ()=>console.log('Server running'));
